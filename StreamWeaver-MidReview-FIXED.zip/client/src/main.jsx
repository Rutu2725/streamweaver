import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { FixedSizeList } from "react-window";
import "./styles.css";

const API = "http://localhost:5000";

function App() {
  const [file, setFile] = useState(null);
  const [job, setJob] = useState(null);
  const [mapping, setMapping] = useState({});
  const [uploading, setUploading] = useState(false);

  async function upload() {
    if (!file) return;
    setUploading(true);
    const form = new FormData();
    form.append("file", file);

    try {
      const response = await fetch(`${API}/api/upload`, {
        method: "POST",
        body: form
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Upload failed");
      setJob(data);
    } catch (e) {
      alert(e.message);
    } finally {
      setUploading(false);
    }
  }

  const progress = file && job
    ? Math.min(100, Math.round((job.bytesReceived / file.size) * 100))
    : 0;

  const rows = job?.previewRows || [];
  const columns = job?.columns || [];

  const Row = ({ index, style }) => {
    const row = rows[index];
    return (
      <div className="gridRow" style={style}>
        <div className="cell rowNo">{row.__rowNumber}</div>
        {columns.map(c => <div className="cell" key={c}>{String(row[c] ?? "")}</div>)}
      </div>
    );
  };

  return (
    <div className="app">
      <header>
        <div>
          <div className="brand">Stream<span>Weaver</span></div>
          <p>High-throughput, memory-safe no-code ETL</p>
        </div>
        <div className="badge">MID-REVIEW BUILD</div>
      </header>

      <main>
        <section className="hero">
          <h1>Stream massive datasets without loading them into RAM.</h1>
          <p>Upload → Stream → Transform → Preview → Map</p>
        </section>

        <section className="card">
          <h2>1. Upload Dataset</h2>
          <div
            className="drop"
            onClick={() => document.getElementById("fileInput").click()}
          >
            <strong>{file ? file.name : "Choose a CSV file"}</strong>
            <span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB` : "Click to browse"}</span>
            <input
              id="fileInput"
              type="file"
              accept=".csv,text/csv"
              hidden
              onChange={e => {
                setFile(e.target.files?.[0] || null);
                setJob(null);
              }}
            />
          </div>

          {file && (
            <button disabled={uploading} onClick={upload}>
              {uploading ? "Streaming..." : "Start Streaming Upload"}
            </button>
          )}

          {uploading && (
            <div className="progress">
              <div style={{ width: `${progress}%` }} />
            </div>
          )}
        </section>

        {job && (
          <>
            <section className="stats">
              <Stat title="Status" value={job.status} />
              <Stat title="Rows Processed" value={job.rowsProcessed.toLocaleString()} />
              <Stat title="Peak RSS" value={`${job.peakRssMB} MB`} />
              <Stat title="Preview Rows" value={rows.length.toLocaleString()} />
            </section>

            <section className="card">
              <h2>2. Streaming Preview</h2>
              <p className="muted">
                Only the first 1,000 rows are previewed. The grid is virtualized.
              </p>
              {rows.length > 0 ? (
                <div className="grid">
                  <div className="gridHeader">
                    <div className="cell rowNo">#</div>
                    {columns.map(c => <div className="cell" key={c}>{c}</div>)}
                  </div>
                  <FixedSizeList
                    height={420}
                    width="100%"
                    itemCount={rows.length}
                    itemSize={42}
                  >
                    {Row}
                  </FixedSizeList>
                </div>
              ) : (
                <p>No preview rows found.</p>
              )}
            </section>

            <section className="card">
              <h2>3. Column Mapping</h2>
              <p className="muted">Map source columns to destination MongoDB fields.</p>
              <div className="mapping">
                {columns.map(source => (
                  <div className="mapRow" key={source}>
                    <span>{source}</span>
                    <span>→</span>
                    <input
                      value={mapping[source] ?? ""}
                      placeholder="destinationField"
                      onChange={e => setMapping({
                        ...mapping,
                        [source]: e.target.value
                      })}
                    />
                  </div>
                ))}
              </div>
            </section>

            <section className="card audit">
              <h2>4. Memory Audit</h2>
              <div className="auditGrid">
                <Metric label="File Size" value={`${(file.size / 1024 / 1024).toFixed(2)} MB`} />
                <Metric label="Peak RSS" value={`${job.peakRssMB} MB`} />
                <Metric label="Heap Used" value={`${job.memory.heapUsedMB} MB`} />
                <Metric label="External" value={`${job.memory.externalMB} MB`} />
              </div>
              <p className="muted">
                These values come from Node.js process.memoryUsage(); they are not hard-coded.
              </p>
            </section>
          </>
        )}
      </main>
    </div>
  );
}

function Stat({ title, value }) {
  return <div className="stat"><span>{title}</span><strong>{value}</strong></div>;
}

function Metric({ label, value }) {
  return <div><span>{label}</span><strong>{value}</strong></div>;
}

createRoot(document.getElementById("root")).render(<App />);
