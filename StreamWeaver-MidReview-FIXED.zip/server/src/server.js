import express from "express";
import cors from "cors";
import busboy from "busboy";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";
import csv from "csv-parser";
import { Transform, pipeline } from "stream";
import { promisify } from "util";

const pipelineAsync = promisify(pipeline);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadDir = path.join(__dirname, "..", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const app = express();
const PORT = Number(process.env.PORT || 5000);
const MAX_FILE_SIZE = Number(process.env.MAX_FILE_SIZE_BYTES || 10 * 1024 ** 3);
const PREVIEW_ROWS = Number(process.env.PREVIEW_ROWS || 1000);

app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json());

const jobs = new Map();

app.get("/api/health", (_, res) => {
  res.json({ ok: true, service: "StreamWeaver", time: new Date().toISOString() });
});

app.get("/api/jobs/:id", (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: "Job not found" });
  res.json(job);
});

app.post("/api/upload", (req, res) => {
  const contentLength = Number(req.headers["content-length"] || 0);
  if (contentLength > MAX_FILE_SIZE) {
    return res.status(413).json({ error: "File is larger than the configured limit." });
  }

  const jobId = crypto.randomUUID();
  const job = {
    id: jobId,
    status: "uploading",
    originalName: null,
    storedPath: null,
    bytesReceived: 0,
    fileSize: contentLength || null,
    rowsProcessed: 0,
    previewRows: [],
    columns: [],
    memory: process.memoryUsage(),
    peakRss: process.memoryUsage().rss,
    startedAt: new Date().toISOString(),
    error: null
  };
  jobs.set(jobId, job);

  let bb;
  try {
    bb = busboy({
      headers: req.headers,
      limits: { fileSize: MAX_FILE_SIZE, files: 1 }
    });
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  let uploadPromise;
  let uploadFileSeen = false;

  bb.on("file", (fieldname, file, info) => {
    uploadFileSeen = true;
    const safeName = path.basename(info.filename).replace(/[^a-zA-Z0-9._-]/g, "_");
    job.originalName = safeName;

    const outputPath = path.join(uploadDir, `${jobId}-${safeName}`);
    job.storedPath = outputPath;

    const writeStream = fs.createWriteStream(outputPath, { flags: "wx" });
    file.on("data", chunk => {
      job.bytesReceived += chunk.length;
      job.memory = process.memoryUsage();
      job.peakRss = Math.max(job.peakRss, job.memory.rss);
    });

    file.on("limit", () => {
      job.error = "File exceeded maximum allowed size.";
      job.status = "failed";
      file.destroy(new Error("File too large"));
    });

    uploadPromise = pipelineAsync(file, writeStream);
  });

  bb.on("finish", async () => {
    if (!uploadFileSeen) {
      job.status = "failed";
      job.error = "No file field received.";
      return res.status(400).json({ error: job.error });
    }

    try {
      await uploadPromise;
      job.status = "processing";
      await processCsv(job);
      job.status = "completed";
      job.completedAt = new Date().toISOString();
      job.memory = process.memoryUsage();
      job.peakRss = Math.max(job.peakRss, job.memory.rss);
      res.json(publicJob(job));
    } catch (err) {
      job.status = "failed";
      job.error = err.message;
      res.status(500).json({ error: err.message, job: publicJob(job) });
    }
  });

  bb.on("error", err => {
    job.status = "failed";
    job.error = err.message;
  });

  req.pipe(bb);
});

async function processCsv(job) {
  const preview = [];
  const columns = new Set();
  let rowCount = 0;

  const transform = new Transform({
    objectMode: true,
    transform(row, _, callback) {
      rowCount++;
      for (const key of Object.keys(row)) columns.add(key);

      if (preview.length < PREVIEW_ROWS) {
        preview.push({ ...row, __rowNumber: rowCount });
      }

      job.rowsProcessed = rowCount;
      job.previewRows = preview;
      job.columns = [...columns];
      job.memory = process.memoryUsage();
      job.peakRss = Math.max(job.peakRss, job.memory.rss);

      callback(null, row);
    }
  });

  // The transform intentionally consumes one row at a time.
  // We do not collect the complete CSV in an array.
  await pipelineAsync(
    fs.createReadStream(job.storedPath),
    csv(),
    transform
  );
}

function publicJob(job) {
  return {
    ...job,
    memory: {
      rssMB: +(job.memory.rss / 1024 / 1024).toFixed(2),
      heapUsedMB: +(job.memory.heapUsed / 1024 / 1024).toFixed(2),
      heapTotalMB: +(job.memory.heapTotal / 1024 / 1024).toFixed(2),
      externalMB: +(job.memory.external / 1024 / 1024).toFixed(2)
    },
    peakRssMB: +(job.peakRss / 1024 / 1024).toFixed(2)
  };
}

app.listen(PORT, () => {
  console.log(`StreamWeaver backend running at http://localhost:${PORT}`);
});
