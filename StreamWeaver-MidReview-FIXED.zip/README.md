# StreamWeaver — Mid-Review Build

This build covers the mid-review scope:

- Streaming multipart upload with Busboy
- Node.js filesystem streams
- Streaming CSV parsing
- Native `stream.Transform`
- Backpressure through `stream.pipeline`
- First 1000-row preview
- React virtualization with `react-window`
- Visual column mapping
- Real Node.js memory metrics

## Requirements

- Node.js 20+ recommended
- npm

## Install

From the project root:

```bash
npm install
npm run install-all
```

## Run

```bash
npm run dev
```

Frontend:
http://localhost:5173

Backend:
http://localhost:5000/api/health

## Test

Use a CSV file and upload it from the UI.

For a larger test, generate a CSV with many rows and upload it. Do not start with 2GB until the small test works.

## Important

The mid-review build intentionally does NOT yet include:

- isolated-vm
- MongoDB bulkWrite
- WebSockets
- final error explorer
- authentication

Those are later milestones.

The memory figures shown by the application are collected from `process.memoryUsage()` and are not hard-coded.
